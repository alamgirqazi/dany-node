# How to run

```
npm install

or

yarn install
```

```
npm run dev
```

Go to [locahost:3000](http://localhost:3000)

This Node.js / Express app is set up using Mongoose / MongoDB.
